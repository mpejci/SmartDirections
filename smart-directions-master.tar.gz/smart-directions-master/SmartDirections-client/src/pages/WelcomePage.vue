<template>
  <q-page>
        <div class="text-center">
            <br><br>
            <div class="text-h6 text-center">International Education Program Veleri-OI IoT School</div>
            <div class="text-h6 text-center text-grey">
              Welcome Page for "Smart Directions"
            </div>
            <br><br><br><br>
            <q-img src="../images/logo_smart_directions_croatia.jpg"  max-height="40vh"
              width="40vh" />
            </div>
  </q-page>
</template>
<script>
</script>
