<template>
  <div>
    Ovo je SearchIndex.vue
  </div>
</template>
<script>
</script>
