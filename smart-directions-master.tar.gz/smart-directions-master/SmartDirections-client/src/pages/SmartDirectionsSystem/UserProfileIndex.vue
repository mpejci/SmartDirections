<template>
  <div>
    Ovo je UserProfileIndex.vue
  </div>
</template>
<script>
</script>
