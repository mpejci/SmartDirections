<template>
  <div>
    Ovo je MainMenuIndex.vue
  </div>
</template>
<script>
</script>
