<template>
  <div>
    Ovo je NearbyIndex.vue
  </div>
</template>
<script>
</script>
